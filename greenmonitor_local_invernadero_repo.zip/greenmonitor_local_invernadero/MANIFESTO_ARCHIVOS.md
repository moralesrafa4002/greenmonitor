# Manifiesto de archivos incluidos

Este archivo resume qué contiene el repositorio y para qué sirve cada sección.

| Carpeta/archivo | Propósito |
|---|---|
| `README.md` | Explicación general, ejecución y alcance del proyecto. |
| `GITHUB_SETUP.md` | Guía para crear el repositorio en GitHub y subir archivos. |
| `run.py` | Archivo principal para ejecutar la app web local. |
| `docs/` | Documentación por fases. |
| `diagrams/` | Diagramas obligatorios con imagen y código editable. |
| `database/mysql/` | Scripts formales para MySQL. |
| `database/sqlite/` | Esquema usado por la app local. |
| `database/dictionary/` | Diccionario de datos en Markdown y CSV. |
| `database/seed_data/` | Datos de prueba. |
| `src/greenmonitor/` | Código fuente de la aplicación. |
| `scripts/` | Scripts auxiliares para ejecución, Git y MySQL. |
| `tests/` | Pruebas básicas de reglas. |

## Verificación rápida

Para validar que el proyecto funciona:

```bash
python run.py
```

Abrir:

```text
http://localhost:8000
```

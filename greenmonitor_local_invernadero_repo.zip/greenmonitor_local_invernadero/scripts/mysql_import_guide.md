# Guía rápida para importar en MySQL Workbench

1. Abre MySQL Workbench.
2. Conéctate a tu servidor local.
3. Abre el archivo:

```text
database/mysql/05_full_script_greenmonitor.sql
```

4. Ejecuta todo el script.
5. Refresca el panel de esquemas.
6. Debe aparecer la base:

```text
greenmonitor_db
```

7. Revisa tablas como:

- zona_invernadero
- sensor
- fuente_datos
- registro_ambiental
- regla_negocio
- alerta
- usuario_sistema
- bitacora_acceso
- estadistica_horaria
- estadistica_diaria

8. Ejecuta las consultas del archivo `03_views_and_queries.sql` para verificar registros y reportes.

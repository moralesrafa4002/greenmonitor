"""
Ejemplo conceptual para obtener datos exteriores desde NASA POWER.

Este archivo no se ejecuta automáticamente porque el proyecto local funciona sin Internet.
Sirve para documentar cómo se podrían obtener datos meteorológicos externos.
"""
from urllib.parse import urlencode

BASE_URL = "https://power.larc.nasa.gov/api/temporal/hourly/point"
params = {
    "parameters": "T2M,RH2M,ALLSKY_SFC_SW_DWN",
    "community": "AG",
    "longitude": -99.1332,
    "latitude": 19.4326,
    "start": "20260608",
    "end": "20260608",
    "format": "JSON",
}

url = BASE_URL + "?" + urlencode(params)
print(url)

# En una implementación conectada se podría usar urllib.request para descargar JSON,
# transformar las variables al formato interno y guardarlas en registro_ambiental.

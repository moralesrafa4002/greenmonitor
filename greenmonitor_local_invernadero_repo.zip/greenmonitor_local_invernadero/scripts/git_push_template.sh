#!/usr/bin/env bash
# Cambia TU_USUARIO por tu usuario real de GitHub.
# Ejecuta este script desde la raíz del proyecto.

git init
git add .
git commit -m "Proyecto GreenMonitor Local completo"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/greenmonitor-local-invernadero.git
git push -u origin main

# Referencias

## NASA POWER

NASA POWER proporciona servicios de datos meteorológicos y solares mediante APIs que entregan información lista para análisis. En este proyecto se usa como referencia conceptual para datos exteriores como temperatura, humedad y radiación solar.

- NASA POWER API Overview: https://power.larc.nasa.gov/docs/services/api/
- NASA POWER Hourly API: https://power.larc.nasa.gov/docs/services/api/temporal/hourly/

## Scrum

Se tomó como base el enfoque de Scrum para organizar el proyecto en backlog, sprints, entregables incrementales y revisión continua.

- Scrum Guide 2020: https://scrumguides.org/scrum-guide.html

## MySQL

Se usó MySQL como base formal del proyecto porque permite modelar tablas relacionales, llaves primarias, llaves foráneas, restricciones y vistas.

- MySQL Reference Manual — Foreign Key Constraints: https://dev.mysql.com/doc/refman/8.4/en/create-table-foreign-keys.html

## SQLite

SQLite se utilizó para una versión local ejecutable sin instalar servidor de base de datos. Esto facilita la prueba de la interfaz web en cualquier computadora con Python.

- SQLite Documentation: https://www.sqlite.org/docs.html

## Python

La interfaz local usa módulos estándar de Python para levantar un servidor HTTP y manejar una base de datos SQLite.

- Python Standard Library — http.server: https://docs.python.org/3/library/http.server.html
- Python Standard Library — sqlite3: https://docs.python.org/3/library/sqlite3.html

## Nota sobre los datos de prueba

Los datos ambientales incluidos son simulados con valores realistas para demostrar el funcionamiento del sistema. No representan mediciones reales de un invernadero específico. Su finalidad es permitir pruebas, consultas, estadísticas y generación de alertas.

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse
from pathlib import Path
import json

from .database import initialize_database
from .repository import (
    dashboard_counts,
    list_records,
    list_active_alerts,
    hourly_stats,
    daily_stats,
    list_zones,
    add_record,
)
from .templates import layout, card, table

STATIC_DIR = Path(__file__).resolve().parent / "static"


def parse_float(value):
    if value in (None, "", []):
        return None
    if isinstance(value, list):
        value = value[0]
    return float(value)


def parse_int(value):
    if value in (None, "", []):
        return None
    if isinstance(value, list):
        value = value[0]
    return int(value)


class GreenMonitorHandler(BaseHTTPRequestHandler):
    def _send_html(self, html, status=200):
        data = html.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _send_json(self, payload, status=200):
        data = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _redirect(self, location):
        self.send_response(303)
        self.send_header("Location", location)
        self.end_headers()

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        if path.startswith("/static/"):
            return self.serve_static(path)
        if path == "/":
            return self.dashboard()
        if path == "/registros":
            return self.registros(qs)
        if path == "/alertas":
            return self.alertas()
        if path == "/estadisticas":
            return self.estadisticas()
        if path == "/nuevo":
            return self.nuevo()
        if path == "/documentacion":
            return self.documentacion()
        if path == "/api/registros":
            return self._send_json(list_records(
                date=qs.get("fecha", [None])[0],
                zone_id=qs.get("zona", [None])[0],
                zone_type=qs.get("tipo", [None])[0],
            ))
        if path == "/api/alertas":
            return self._send_json(list_active_alerts())
        if path == "/api/estadisticas/hora":
            return self._send_json(hourly_stats())
        if path == "/api/estadisticas/dia":
            return self._send_json(daily_stats())

        self._send_html(layout("No encontrado", "<h2>Ruta no encontrada</h2>"), 404)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path != "/nuevo":
            return self._send_html(layout("No permitido", "<h2>Ruta no permitida</h2>"), 405)

        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length).decode("utf-8")
        form = parse_qs(body)
        data = {
            "id_zona": parse_int(form.get("id_zona")),
            "id_sensor": None,
            "id_fuente": 2,
            "fecha_hora": form.get("fecha_hora", [""])[0].replace("T", " ") + ":00",
            "temperatura_c": parse_float(form.get("temperatura_c")),
            "humedad_relativa_pct": parse_float(form.get("humedad_relativa_pct")),
            "humedad_suelo_pct": parse_float(form.get("humedad_suelo_pct")),
            "radiacion_solar_wm2": parse_float(form.get("radiacion_solar_wm2")),
            "indice_uv": parse_float(form.get("indice_uv")),
            "estado_ventilacion": form.get("estado_ventilacion", ["NO_APLICA"])[0],
            "observaciones": form.get("observaciones", ["Registro capturado desde interfaz local."])[0],
        }
        add_record(data)
        self._redirect("/alertas")

    def serve_static(self, path):
        file_path = STATIC_DIR / path.replace("/static/", "")
        if not file_path.exists():
            return self._send_html("Archivo no encontrado", 404)
        content_type = "text/css" if file_path.suffix == ".css" else "application/javascript"
        data = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def dashboard(self):
        counts = dashboard_counts()
        recent = list_records()[:5]
        content = """
        <section class="hero">
            <h2>Dashboard ambiental</h2>
            <p>Consulta rápida del estado del invernadero, registros recientes y alertas activas.</p>
        </section>
        <section class="cards">
        """
        content += card("Registros", counts["registros"], "Mediciones almacenadas")
        content += card("Alertas activas", counts["alertas_activas"], "Condiciones por atender")
        content += card("Zonas", counts["zonas"], "Interiores y exteriores")
        content += card("Sensores", counts["sensores"], "Sensores activos")
        content += "</section><h2>Registros recientes</h2>"
        content += table(
            ["Fecha", "Zona", "Tipo", "Temp °C", "HR %", "Suelo %", "Radiación", "UV", "Ventilación"],
            [[r["fecha_hora"], r["zona"], r["tipo_zona"], r["temperatura_c"], r["humedad_relativa_pct"], r["humedad_suelo_pct"], r["radiacion_solar_wm2"], r["indice_uv"], r["estado_ventilacion"]] for r in recent]
        )
        self._send_html(layout("Dashboard", content))

    def registros(self, qs):
        fecha = qs.get("fecha", [""])[0]
        zona = qs.get("zona", [""])[0]
        tipo = qs.get("tipo", [""])[0]
        zonas = list_zones()
        registros = list_records(date=fecha or None, zone_id=zona or None, zone_type=tipo or None)
        zone_options = "<option value=''>Todas</option>" + "".join(f"<option value='{z['id_zona']}' {'selected' if str(z['id_zona'])==zona else ''}>{z['nombre']}</option>" for z in zonas)
        content = f"""
        <h2>Registros ambientales</h2>
        <form class="filters" method="get">
            <label>Fecha <input type="date" name="fecha" value="{fecha}"></label>
            <label>Zona <select name="zona">{zone_options}</select></label>
            <label>Tipo <select name="tipo">
                <option value="">Todos</option>
                <option value="INTERIOR" {'selected' if tipo=='INTERIOR' else ''}>Interior</option>
                <option value="EXTERIOR" {'selected' if tipo=='EXTERIOR' else ''}>Exterior</option>
            </select></label>
            <button type="submit">Filtrar</button>
            <a class="button secondary" href="/registros">Limpiar</a>
        </form>
        """
        content += table(
            ["ID", "Fecha", "Zona", "Tipo", "Fuente", "Temp °C", "HR %", "Suelo %", "Rad W/m²", "UV", "Ventilación", "Observaciones"],
            [[r["id_registro"], r["fecha_hora"], r["zona"], r["tipo_zona"], r["nombre_fuente"], r["temperatura_c"], r["humedad_relativa_pct"], r["humedad_suelo_pct"], r["radiacion_solar_wm2"], r["indice_uv"], r["estado_ventilacion"], r["observaciones"]] for r in registros]
        )
        self._send_html(layout("Registros", content))

    def alertas(self):
        alertas = list_active_alerts()
        content = "<h2>Alertas activas</h2><p>Estas alertas se generan automáticamente al evaluar las reglas de negocio.</p>"
        content += table(
            ["ID", "Fecha alerta", "Severidad", "Zona", "Tipo", "Regla", "Mensaje", "Acción recomendada"],
            [[a["id_alerta"], a["fecha_hora_alerta"], a["severidad"], a["zona"], a["tipo_zona"], a["nombre_regla"], a["mensaje"], a["accion_recomendada"]] for a in alertas]
        )
        self._send_html(layout("Alertas", content))

    def estadisticas(self):
        hs = hourly_stats()
        ds = daily_stats()
        content = "<h2>Estadísticas por hora</h2>"
        content += table(
            ["Zona", "Fecha", "Hora", "Temp prom", "Temp min", "Temp max", "HR prom", "Suelo prom", "Rad prom", "UV prom", "Total"],
            [[r["zona"], r["fecha"], r["hora"], r["temperatura_promedio"], r["temperatura_min"], r["temperatura_max"], r["humedad_promedio"], r["humedad_suelo_promedio"], r["radiacion_promedio"], r["uv_promedio"], r["total_registros"]] for r in hs]
        )
        content += "<h2>Estadísticas por día</h2>"
        content += table(
            ["Zona", "Fecha", "Temp prom", "Temp min", "Temp max", "HR prom", "Suelo prom", "Rad prom", "UV prom", "Total"],
            [[r["zona"], r["fecha"], r["temperatura_promedio"], r["temperatura_min"], r["temperatura_max"], r["humedad_promedio"], r["humedad_suelo_promedio"], r["radiacion_promedio"], r["uv_promedio"], r["total_registros"]] for r in ds]
        )
        self._send_html(layout("Estadísticas", content))

    def nuevo(self):
        zonas = list_zones()
        zone_options = "".join(f"<option value='{z['id_zona']}'>{z['nombre']} ({z['tipo_zona']})</option>" for z in zonas)
        content = f"""
        <h2>Nuevo registro ambiental</h2>
        <p>Al guardar el registro, el sistema evaluará automáticamente las reglas de negocio y generará alertas si corresponde.</p>
        <form class="form" method="post">
            <label>Zona <select name="id_zona" required>{zone_options}</select></label>
            <label>Fecha y hora <input type="datetime-local" name="fecha_hora" required value="2026-06-08T16:00"></label>
            <label>Temperatura °C <input type="number" step="0.1" name="temperatura_c" required value="33.5"></label>
            <label>Humedad relativa % <input type="number" step="0.1" name="humedad_relativa_pct" required value="43"></label>
            <label>Humedad suelo % <input type="number" step="0.1" name="humedad_suelo_pct" value="32"></label>
            <label>Radiación solar W/m² <input type="number" step="0.1" name="radiacion_solar_wm2" value="850"></label>
            <label>Índice UV <input type="number" step="0.1" name="indice_uv" value="8.4"></label>
            <label>Ventilación <select name="estado_ventilacion">
                <option>ABIERTA</option><option>CERRADA</option><option>AUTOMATICA</option><option>NO_APLICA</option>
            </select></label>
            <label>Observaciones <textarea name="observaciones">Registro capturado desde interfaz local.</textarea></label>
            <button type="submit">Guardar registro y evaluar alertas</button>
        </form>
        """
        self._send_html(layout("Nuevo registro", content))

    def documentacion(self):
        content = """
        <h2>Documentación integrada</h2>
        <p>La documentación completa está organizada por fases dentro de la carpeta <code>docs/</code>.</p>
        <ul class="doc-list">
            <li><strong>Fase 1:</strong> Scrum, backlog, historias y sprints.</li>
            <li><strong>Fase 2:</strong> Diagrama de contexto, DFD Nivel 0 y DFD Nivel 1.</li>
            <li><strong>Fase 3:</strong> Diccionario de datos, modelo ER y normalización.</li>
            <li><strong>Fase 4:</strong> Scripts SQL MySQL y SQLite.</li>
            <li><strong>Fase 5:</strong> Interfaz web local.</li>
            <li><strong>Fase 6:</strong> Pruebas y evidencias.</li>
            <li><strong>Fase 7:</strong> Despliegue local y SSH.</li>
            <li><strong>Referencias:</strong> NASA POWER, Scrum, MySQL, SQLite y Python.</li>
        </ul>
        """
        self._send_html(layout("Documentación", content))


def run_server(host="0.0.0.0", port=8000):
    initialize_database()
    server = ThreadingHTTPServer((host, port), GreenMonitorHandler)
    print(f"GreenMonitor Local iniciado en http://localhost:{port}")
    print("Presiona Ctrl+C para detener el servidor.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("Servidor detenido.")
    finally:
        server.server_close()

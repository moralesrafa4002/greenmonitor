from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_ROOT / "data"
DB_PATH = DATA_DIR / "greenmonitor.db"
SCHEMA_PATH = PROJECT_ROOT / "database" / "sqlite" / "greenmonitor_sqlite_schema.sql"

def compare(value, operator, threshold):
    if value is None or threshold is None:
        return False
    if operator == ">":
        return value > threshold
    if operator == ">=":
        return value >= threshold
    if operator == "<":
        return value < threshold
    if operator == "<=":
        return value <= threshold
    if operator == "=":
        return value == threshold
    if operator == "!=":
        return value != threshold
    return False


def evaluate_record(conn, registro_id):
    registro = conn.execute(
        """
        SELECT r.*, z.tipo_zona, z.nombre AS zona_nombre
        FROM registro_ambiental r
        JOIN zona_invernadero z ON r.id_zona = z.id_zona
        WHERE r.id_registro = ?
        """,
        (registro_id,),
    ).fetchone()
    if not registro:
        return []

    reglas = conn.execute("SELECT * FROM regla_negocio WHERE activa = 1").fetchall()
    created_alerts = []

    for regla in reglas:
        applies = False

        if regla["nombre_regla"] == "Temperatura interior excesiva":
            applies = registro["tipo_zona"] == "INTERIOR" and compare(registro["temperatura_c"], regla["operador"], regla["valor_umbral"])
        elif regla["nombre_regla"] == "Temperatura exterior crítica":
            applies = registro["tipo_zona"] == "EXTERIOR" and compare(registro["temperatura_c"], regla["operador"], regla["valor_umbral"])
        elif regla["operador"] == "COMPUESTA" and regla["variable_evaluada"] == "estres_hidrico":
            temp = registro["temperatura_c"] or 0
            suelo = registro["humedad_suelo_pct"]
            applies = registro["tipo_zona"] == "INTERIOR" and suelo is not None and temp > 32 and suelo < 35
        else:
            variable = regla["variable_evaluada"]
            if variable in registro.keys():
                applies = compare(registro[variable], regla["operador"], regla["valor_umbral"])

        if applies:
            duplicate = conn.execute(
                "SELECT COUNT(*) AS total FROM alerta WHERE id_registro = ? AND id_regla = ?",
                (registro_id, regla["id_regla"]),
            ).fetchone()["total"]
            if duplicate == 0:
                mensaje = f'{regla["mensaje_alerta"]} Zona: {registro["zona_nombre"]}. Registro: {registro["fecha_hora"]}.'
                conn.execute(
                    """
                    INSERT INTO alerta(id_registro, id_regla, severidad, mensaje, accion_recomendada)
                    VALUES (?, ?, ?, ?, ?)
                    """,
                    (registro_id, regla["id_regla"], regla["severidad"], mensaje, recommended_action(regla["nombre_regla"])),
                )
                created_alerts.append(mensaje)

    return created_alerts


def recommended_action(rule_name):
    recommendations = {
        "Temperatura interior excesiva": "Abrir ventilación, revisar sombreado y monitorear la temperatura cada 30 minutos.",
        "Temperatura exterior crítica": "Reducir exposición directa y revisar diferencia entre exterior e interior.",
        "Humedad relativa insuficiente": "Activar nebulización o revisar programación de riego.",
        "Humedad de suelo baja": "Revisar riego por goteo y humedad del sustrato.",
        "Índice UV alto": "Usar malla sombra o protección adicional para el cultivo.",
        "Radiación solar alta": "Revisar sombreado y ventilación.",
        "Estrés hídrico": "Priorizar riego, revisar raíces y evitar exposición prolongada al calor.",
    }
    return recommendations.get(rule_name, "Revisar condición ambiental y registrar acción tomada.")


def evaluate_existing_records(conn):
    registros = conn.execute("SELECT id_registro FROM registro_ambiental").fetchall()
    for row in registros:
        evaluate_record(conn, row["id_registro"])

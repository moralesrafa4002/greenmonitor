from html import escape


def layout(title, content):
    return f"""<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{escape(title)} | GreenMonitor Local</title>
    <link rel="stylesheet" href="/static/style.css">
</head>
<body>
    <header class="topbar">
        <div>
            <h1>GreenMonitor Local</h1>
            <p>Sistema local de monitoreo ambiental y generación de alertas para invernaderos</p>
        </div>
        <nav>
            <a href="/">Dashboard</a>
            <a href="/registros">Registros</a>
            <a href="/alertas">Alertas</a>
            <a href="/estadisticas">Estadísticas</a>
            <a href="/nuevo">Nuevo registro</a>
            <a href="/documentacion">Documentación</a>
        </nav>
    </header>
    <main class="container">
        {content}
    </main>
    <footer>
        Proyecto académico ejecutado localmente. Base SQLite para demo y scripts MySQL para entrega formal.
    </footer>
</body>
</html>"""


def card(title, value, detail=""):
    return f"""<article class="card"><h3>{escape(title)}</h3><strong>{escape(str(value))}</strong><span>{escape(detail)}</span></article>"""


def table(headers, rows):
    head = "".join(f"<th>{escape(h)}</th>" for h in headers)
    body = ""
    for row in rows:
        body += "<tr>" + "".join(f"<td>{escape('' if v is None else str(v))}</td>" for v in row) + "</tr>"
    if not rows:
        body = f"<tr><td colspan='{len(headers)}'>No hay datos para mostrar.</td></tr>"
    return f"<div class='table-wrap'><table><thead><tr>{head}</tr></thead><tbody>{body}</tbody></table></div>"

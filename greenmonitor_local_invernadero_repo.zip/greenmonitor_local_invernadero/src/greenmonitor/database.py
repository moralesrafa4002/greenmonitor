import sqlite3
from datetime import datetime, timedelta
from pathlib import Path
from .config import DB_PATH, DATA_DIR, SCHEMA_PATH


def get_connection():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialize_database():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = get_connection()
    with open(SCHEMA_PATH, "r", encoding="utf-8") as f:
        conn.executescript(f.read())
    seed_if_empty(conn)
    conn.commit()
    conn.close()


def seed_if_empty(conn):
    count = conn.execute("SELECT COUNT(*) AS total FROM zona_invernadero").fetchone()["total"]
    if count > 0:
        return

    zonas = [
        ("Nave 1 - Cultivo principal", "INTERIOR", "Zona interna de cultivo principal.", "Interior centro"),
        ("Nave 2 - Germinación", "INTERIOR", "Zona de germinación y plántulas.", "Interior oriente"),
        ("Exterior norte", "EXTERIOR", "Punto exterior para comparación meteorológica.", "Norte del invernadero"),
        ("Exterior sur", "EXTERIOR", "Punto exterior para UV y radiación.", "Sur del invernadero"),
    ]
    conn.executemany(
        "INSERT INTO zona_invernadero(nombre, tipo_zona, descripcion, ubicacion_referencia) VALUES (?, ?, ?, ?)",
        zonas,
    )

    sensores = [
        (1, "GM-MULTI-001", "MULTIVARIABLE", "varias", "Sensor multivariable interior nave 1.", "2026-06-01"),
        (2, "GM-MULTI-002", "MULTIVARIABLE", "varias", "Sensor multivariable interior nave 2.", "2026-06-01"),
        (3, "GM-EXT-001", "MULTIVARIABLE", "varias", "Sensor exterior norte.", "2026-06-01"),
        (4, "GM-EXT-002", "MULTIVARIABLE", "varias", "Sensor exterior sur.", "2026-06-01"),
    ]
    conn.executemany(
        """
        INSERT INTO sensor(id_zona, codigo_sensor, tipo_sensor, unidad_medida, descripcion, fecha_instalacion)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        sensores,
    )

    fuentes = [
        ("Sensor local GreenMonitor", "SENSOR_LOCAL", None, "Datos capturados por sensores locales."),
        ("Captura manual operador", "CAPTURA_MANUAL", None, "Datos capturados desde la interfaz web."),
        ("NASA POWER Hourly API", "API_EXTERNA", "https://power.larc.nasa.gov/docs/services/api/temporal/hourly/", "Datos meteorológicos exteriores de referencia."),
        ("Simulación académica", "SIMULACION", None, "Datos de prueba generados para el proyecto."),
    ]
    conn.executemany(
        "INSERT INTO fuente_datos(nombre_fuente, tipo_fuente, url_referencia, descripcion) VALUES (?, ?, ?, ?)",
        fuentes,
    )

    reglas = [
        ("Temperatura interior excesiva", "Zona interior supera 32 °C.", "temperatura_c", ">", 32.0, "°C", "ALTA", "Temperatura interior excesiva. Revisar ventilación y sombreado."),
        ("Temperatura exterior crítica", "Zona exterior supera 35 °C.", "temperatura_c", ">", 35.0, "°C", "MEDIA", "Temperatura exterior alta. Considerar protección térmica."),
        ("Humedad relativa insuficiente", "Humedad relativa menor a 45%.", "humedad_relativa_pct", "<", 45.0, "%", "MEDIA", "Humedad relativa insuficiente. Revisar nebulización o riego."),
        ("Humedad de suelo baja", "Humedad de suelo menor a 35%.", "humedad_suelo_pct", "<", 35.0, "%", "ALTA", "Humedad del suelo baja. Revisar sistema de riego."),
        ("Índice UV alto", "Índice UV mayor a 8.", "indice_uv", ">", 8.0, "UV", "MEDIA", "Índice UV alto. Revisar malla sombra o protección."),
        ("Radiación solar alta", "Radiación solar mayor a 800 W/m².", "radiacion_solar_wm2", ">", 800.0, "W/m²", "MEDIA", "Radiación solar alta. Revisar sombreado."),
        ("Estrés hídrico", "Temperatura alta y humedad de suelo baja.", "estres_hidrico", "COMPUESTA", None, None, "CRITICA", "Posible estrés hídrico. Priorizar riego y revisión del cultivo."),
    ]
    conn.executemany(
        """
        INSERT INTO regla_negocio(nombre_regla, descripcion, variable_evaluada, operador, valor_umbral, unidad, severidad, mensaje_alerta)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        """,
        reglas,
    )

    usuarios = [
        ("Administrador local", "ADMINISTRADOR", "admin"),
        ("Operador invernadero", "OPERADOR", "operador"),
        ("Consulta académica", "CONSULTA", "consulta"),
    ]
    conn.executemany(
        "INSERT INTO usuario_sistema(nombre, rol, usuario_login) VALUES (?, ?, ?)",
        usuarios,
    )

    registros = [
        (1, 1, 4, "2026-06-08 08:00:00", 24.8, 67, 58, 310, 2.1, "AUTOMATICA", "Condición normal matutina."),
        (1, 1, 4, "2026-06-08 10:00:00", 28.4, 59, 49, 540, 5.3, "AUTOMATICA", "Aumento gradual de temperatura."),
        (1, 1, 4, "2026-06-08 12:00:00", 33.7, 42, 31, 870, 8.5, "ABIERTA", "Condición calurosa con suelo bajo."),
        (2, 2, 4, "2026-06-08 12:00:00", 30.2, 55, 41, 650, 6.7, "AUTOMATICA", "Germinación estable."),
        (3, 3, 4, "2026-06-08 12:00:00", 36.1, 38, None, 910, 9.2, "NO_APLICA", "Exterior con alta radiación."),
        (4, 4, 4, "2026-06-08 15:00:00", 34.9, 40, None, 790, 8.9, "NO_APLICA", "Exterior sur con UV alto."),
        (1, 1, 4, "2026-06-09 08:00:00", 25.1, 66, 56, 320, 2.2, "AUTOMATICA", "Día siguiente normal."),
        (2, 2, 4, "2026-06-09 13:00:00", 32.9, 44, 34, 820, 8.1, "ABIERTA", "Condición límite en germinación."),
    ]
    conn.executemany(
        """
        INSERT INTO registro_ambiental
        (id_zona, id_sensor, id_fuente, fecha_hora, temperatura_c, humedad_relativa_pct,
         humedad_suelo_pct, radiacion_solar_wm2, indice_uv, estado_ventilacion, observaciones)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        registros,
    )

    from .rules import evaluate_existing_records
    evaluate_existing_records(conn)

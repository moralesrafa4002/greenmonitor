from .database import get_connection
from .rules import evaluate_record


def list_zones():
    with get_connection() as conn:
        return [dict(row) for row in conn.execute("SELECT * FROM zona_invernadero ORDER BY tipo_zona, nombre")]


def dashboard_counts():
    with get_connection() as conn:
        return {
            "registros": conn.execute("SELECT COUNT(*) AS total FROM registro_ambiental").fetchone()["total"],
            "alertas_activas": conn.execute("SELECT COUNT(*) AS total FROM alerta WHERE estado_alerta='ACTIVA'").fetchone()["total"],
            "zonas": conn.execute("SELECT COUNT(*) AS total FROM zona_invernadero WHERE activa=1").fetchone()["total"],
            "sensores": conn.execute("SELECT COUNT(*) AS total FROM sensor WHERE activo=1").fetchone()["total"],
        }


def list_records(date=None, zone_id=None, zone_type=None):
    query = """
        SELECT r.*, z.nombre AS zona, z.tipo_zona, f.nombre_fuente
        FROM registro_ambiental r
        JOIN zona_invernadero z ON r.id_zona = z.id_zona
        JOIN fuente_datos f ON r.id_fuente = f.id_fuente
        WHERE 1=1
    """
    params = []
    if date:
        query += " AND substr(r.fecha_hora, 1, 10) = ?"
        params.append(date)
    if zone_id:
        query += " AND r.id_zona = ?"
        params.append(zone_id)
    if zone_type:
        query += " AND z.tipo_zona = ?"
        params.append(zone_type)
    query += " ORDER BY r.fecha_hora DESC, r.id_registro DESC LIMIT 200"
    with get_connection() as conn:
        return [dict(row) for row in conn.execute(query, params)]


def list_active_alerts():
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT a.*, z.nombre AS zona, z.tipo_zona, rn.nombre_regla, r.fecha_hora AS fecha_registro
            FROM alerta a
            JOIN registro_ambiental r ON a.id_registro = r.id_registro
            JOIN zona_invernadero z ON r.id_zona = z.id_zona
            JOIN regla_negocio rn ON a.id_regla = rn.id_regla
            WHERE a.estado_alerta = 'ACTIVA'
            ORDER BY a.fecha_hora_alerta DESC
            """
        ).fetchall()
        return [dict(row) for row in rows]


def hourly_stats():
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT
                z.nombre AS zona,
                substr(r.fecha_hora, 1, 10) AS fecha,
                substr(r.fecha_hora, 12, 2) AS hora,
                ROUND(AVG(r.temperatura_c), 2) AS temperatura_promedio,
                ROUND(MIN(r.temperatura_c), 2) AS temperatura_min,
                ROUND(MAX(r.temperatura_c), 2) AS temperatura_max,
                ROUND(AVG(r.humedad_relativa_pct), 2) AS humedad_promedio,
                ROUND(AVG(r.humedad_suelo_pct), 2) AS humedad_suelo_promedio,
                ROUND(AVG(r.radiacion_solar_wm2), 2) AS radiacion_promedio,
                ROUND(AVG(r.indice_uv), 2) AS uv_promedio,
                COUNT(*) AS total_registros
            FROM registro_ambiental r
            JOIN zona_invernadero z ON r.id_zona = z.id_zona
            GROUP BY z.nombre, substr(r.fecha_hora, 1, 10), substr(r.fecha_hora, 12, 2)
            ORDER BY fecha DESC, hora DESC, zona
            """
        ).fetchall()
        return [dict(row) for row in rows]


def daily_stats():
    with get_connection() as conn:
        rows = conn.execute(
            """
            SELECT
                z.nombre AS zona,
                substr(r.fecha_hora, 1, 10) AS fecha,
                ROUND(AVG(r.temperatura_c), 2) AS temperatura_promedio,
                ROUND(MIN(r.temperatura_c), 2) AS temperatura_min,
                ROUND(MAX(r.temperatura_c), 2) AS temperatura_max,
                ROUND(AVG(r.humedad_relativa_pct), 2) AS humedad_promedio,
                ROUND(AVG(r.humedad_suelo_pct), 2) AS humedad_suelo_promedio,
                ROUND(AVG(r.radiacion_solar_wm2), 2) AS radiacion_promedio,
                ROUND(AVG(r.indice_uv), 2) AS uv_promedio,
                COUNT(*) AS total_registros
            FROM registro_ambiental r
            JOIN zona_invernadero z ON r.id_zona = z.id_zona
            GROUP BY z.nombre, substr(r.fecha_hora, 1, 10)
            ORDER BY fecha DESC, zona
            """
        ).fetchall()
        return [dict(row) for row in rows]


def add_record(data):
    with get_connection() as conn:
        cursor = conn.execute(
            """
            INSERT INTO registro_ambiental
            (id_zona, id_sensor, id_fuente, fecha_hora, temperatura_c, humedad_relativa_pct,
             humedad_suelo_pct, radiacion_solar_wm2, indice_uv, estado_ventilacion, observaciones)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                data.get("id_zona"),
                data.get("id_sensor"),
                data.get("id_fuente", 2),
                data.get("fecha_hora"),
                data.get("temperatura_c"),
                data.get("humedad_relativa_pct"),
                data.get("humedad_suelo_pct"),
                data.get("radiacion_solar_wm2"),
                data.get("indice_uv"),
                data.get("estado_ventilacion", "NO_APLICA"),
                data.get("observaciones", "Registro capturado desde interfaz local."),
            ),
        )
        registro_id = cursor.lastrowid
        alerts = evaluate_record(conn, registro_id)
        conn.execute(
            "INSERT INTO bitacora_acceso(id_usuario, accion, detalle, ip_origen) VALUES (?, ?, ?, ?)",
            (None, "INSERT_REGISTRO_WEB", f"Registro ambiental {registro_id} insertado desde interfaz web", "LOCAL"),
        )
        conn.commit()
        return registro_id, alerts

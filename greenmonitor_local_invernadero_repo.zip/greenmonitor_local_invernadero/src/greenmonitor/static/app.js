// Archivo reservado para futuras mejoras de interfaz.
// La versión actual funciona con HTML renderizado por el servidor para facilitar la ejecución local.
console.log("GreenMonitor Local cargado correctamente.");

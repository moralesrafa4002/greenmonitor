# Pruebas del proyecto

Este directorio contiene pruebas simples de la lógica de reglas.

Para ejecutar manualmente:

```bash
python -m pytest tests
```

Si no se tiene `pytest`, se puede probar el sistema completo ejecutando:

```bash
python run.py
```

Y abriendo:

```text
http://localhost:8000
```

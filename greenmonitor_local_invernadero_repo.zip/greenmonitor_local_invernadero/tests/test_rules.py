from src.greenmonitor.rules import compare


def test_compare_greater():
    assert compare(33, ">", 32) is True


def test_compare_less():
    assert compare(40, "<", 45) is True


def test_compare_none():
    assert compare(None, ">", 10) is False

# Guía para crear y subir el repositorio a GitHub

Esta carpeta ya está preparada como repositorio. Solo falta crear el repositorio vacío en GitHub y subir los archivos.

## Opción A: desde la página de GitHub

1. Entra a GitHub.
2. Presiona **New repository**.
3. Nombre recomendado:

```text
greenmonitor-local-invernadero
```

4. Descripción recomendada:

```text
Sistema local de monitoreo ambiental y generación de alertas para invernaderos con análisis estructurado, modelo ER, base de datos e interfaz web local.
```

5. Elige público o privado según lo pida el profesor.
6. No agregues README porque este proyecto ya incluye uno.
7. Crea el repositorio.
8. Copia la URL del repositorio.

## Opción B: subir por comandos Git

Desde la carpeta raíz del proyecto ejecuta:

```bash
git init
git add .
git commit -m "Proyecto GreenMonitor Local completo"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/greenmonitor-local-invernadero.git
git push -u origin main
```

Cambia `TU_USUARIO` por tu usuario real de GitHub.

## Opción C: subir desde GitHub Desktop

1. Abre GitHub Desktop.
2. Selecciona **Add existing repository**.
3. Elige esta carpeta.
4. Crea el repositorio desde GitHub Desktop.
5. Presiona **Publish repository**.

## Recomendación para la entrega

En la descripción del repositorio coloca:

```text
Proyecto académico dividido por fases: Scrum, análisis estructurado, DFD, diccionario de datos, modelo ER, UML, base de datos MySQL/SQLite e interfaz web local.
```

También puedes adjuntar este ZIP en la plataforma de tareas y pegar el enlace de GitHub.

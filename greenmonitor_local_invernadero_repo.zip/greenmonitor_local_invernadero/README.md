# GreenMonitor Local — Sistema local de monitoreo ambiental y generación de alertas para invernaderos

Proyecto académico completo para análisis, modelado e implementación de un sistema local de información orientado al monitoreo ambiental de un invernadero.

## Objetivo general

Diseñar, modelar e implementar un sistema local que permita registrar condiciones ambientales internas y externas de un invernadero, almacenar la información en una base de datos, consultar registros históricos, calcular estadísticas básicas y generar alertas automáticas conforme a reglas de negocio definidas por el equipo.

## Alcance del proyecto

El proyecto incluye:

- Metodología ágil Scrum con backlog, historias de usuario, tareas por sprint y evidencias de avance incremental.
- Diagrama de contexto.
- DFD Nivel 0.
- DFD Nivel 1.
- Diccionario de datos completo.
- Modelo Entidad-Relación.
- Diagrama UML de clases.
- Script completo de creación de base de datos MySQL.
- Script SQLite para ejecución local inmediata.
- Interfaz web local ejecutable con Python sin frameworks externos.
- Carga de registros ambientales.
- Consulta de registros interiores y exteriores.
- Consulta de alertas activas.
- Filtros por fecha, zona y tipo de zona.
- Estadísticas básicas por hora y por día.
- Documentación técnica, funcional, de despliegue local y referencias.

## Estructura del repositorio

```text
greenmonitor_local_invernadero/
├── README.md
├── GITHUB_SETUP.md
├── LICENSE
├── .gitignore
├── run.py
├── docs/
│   ├── 00_portada_resumen/
│   ├── 01_fase_scrum/
│   ├── 02_fase_analisis_estructurado/
│   ├── 03_fase_modelado_bd/
│   ├── 04_fase_implementacion_bd/
│   ├── 05_fase_app_web_local/
│   ├── 06_fase_pruebas_evidencias/
│   ├── 07_fase_despliegue_ssh_red_local/
│   └── 08_referencias/
├── diagrams/
│   ├── codigo_mermaid/
│   ├── codigo_dot/
│   └── imagenes_png/
├── database/
│   ├── mysql/
│   ├── sqlite/
│   ├── seed_data/
│   └── dictionary/
├── src/
│   └── greenmonitor/
├── scripts/
└── tests/
```

## Cómo ejecutar el sistema local

El programa está hecho para funcionar de manera clara en una computadora local. Usa Python y SQLite para que se pueda ejecutar sin instalar MySQL al momento de probar la interfaz.

### 1. Requisito

Tener Python 3.10 o superior instalado.

### 2. Ejecutar

Desde la raíz del proyecto:

```bash
python run.py
```

Después abre en el navegador:

```text
http://localhost:8000
```

### 3. Qué hace al ejecutarse

Al iniciar, el sistema:

1. Crea automáticamente la base SQLite local en `data/greenmonitor.db` si no existe.
2. Crea las tablas principales.
3. Inserta zonas, sensores, reglas de negocio y registros ambientales de prueba.
4. Evalúa automáticamente las reglas de negocio.
5. Genera alertas si detecta temperatura excesiva, humedad baja, humedad de suelo insuficiente, UV alto, radiación alta o estrés hídrico.
6. Muestra una interfaz web local para consultar registros, alertas y estadísticas.

## Base de datos

La versión formal de base de datos para entrega está en:

```text
database/mysql/01_create_database.sql
database/mysql/02_insert_seed_data.sql
database/mysql/03_views_and_queries.sql
database/mysql/04_triggers.sql
database/mysql/05_full_script_greenmonitor.sql
```

La versión ejecutable local inmediata está en:

```text
database/sqlite/greenmonitor_sqlite_schema.sql
```

## Diagramas incluidos

Cada diagrama se entrega en dos formas:

1. Imagen PNG lista para insertar en documento o presentación.
2. Código fuente del diagrama para editarlo.

Ubicaciones:

```text
diagrams/imagenes_png/
diagrams/codigo_mermaid/
diagrams/codigo_dot/
```

## Enfoque de datos ambientales

El sistema usa datos internos simulados de sensores y contempla datos externos de referencia con estructura compatible con servicios meteorológicos como NASA POWER. La documentación explica cómo se obtendrían datos externos mediante API y cómo se almacenarían en la tabla `fuente_datos` y `registro_ambiental`.

## Reglas de negocio implementadas

Las reglas principales son:

- Temperatura interior excesiva cuando la temperatura supera 32 °C.
- Temperatura exterior crítica cuando la temperatura supera 35 °C.
- Humedad relativa insuficiente cuando baja de 45 %.
- Humedad del suelo baja cuando baja de 35 %.
- Condición UV alta cuando el índice UV supera 8.
- Radiación solar alta cuando supera 800 W/m².
- Estrés hídrico cuando hay humedad de suelo baja y temperatura alta.
- Ventilación recomendada cuando la temperatura interior es alta o la humedad relativa es elevada.

## Notas para el profesor

Este repositorio está organizado por fases para que cada parte del proyecto pueda revisarse de forma independiente. La documentación no solo muestra el resultado, también explica el objetivo de cada fase, su funcionalidad, cómo se realizó y cómo se conecta con las demás partes del sistema.
